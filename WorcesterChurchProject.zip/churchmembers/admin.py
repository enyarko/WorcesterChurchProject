
from django.contrib import admin
from .models import ChurchMember, Attendance, GuestInformation


@admin.register(ChurchMember)
class ChurchMemberAdmin(admin.ModelAdmin):
    list_display = (
        "firstname",
        "lastname",
        "email",
        "cell_phone",
        "created_at",
    )

    search_fields = (
        "firstname",
        "lastname",
        "email",
        "cell_phone",
    )


@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = (
        "member",
        "date",
        "status",
    )

    list_filter = (
        "date",
        "status",
    )

    search_fields = (
        "member__firstname",
        "member__lastname",
    )


@admin.register(GuestInformation)
class GuestInformationAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "email",
        "phone_mobile",
        "date",
        "created_at",
    )

    search_fields = (
        "name",
        "email",
        "phone_mobile",
    )
