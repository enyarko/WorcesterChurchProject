from django.db import models


class ChurchMember(models.Model):
    YES_NO_CHOICES = [
        ('Yes', 'Yes'),
        ('No', 'No'),
    ]
    
    firstname = models.CharField(max_length=100, null=True, blank=True)
    lastname = models.CharField(max_length=100, null=True, blank=True)
    address = models.CharField(max_length=255, blank=True, null=True)
    home_phone = models.CharField(max_length=20, blank=True, null=True)
    cell_phone = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    birthday = models.DateField(blank=True, null=True)
    baptismal_date = models.DateField(blank=True, null=True)

    # Originating congregation
    originating_congregation = models.CharField(max_length=200, blank=True, null=True)
    membership_date = models.DateField(blank=True, null=True)
    old_congregation_contact = models.TextField(blank=True, null=True)

    # Additional information
    move_date = models.CharField(max_length=100, blank=True, null=True)
    live_with = models.CharField(max_length=200, blank=True, null=True)
    married_now = models.CharField(max_length=3, choices=YES_NO_CHOICES, blank=True, null=True)
    married_before = models.CharField(max_length=3, choices=YES_NO_CHOICES, blank=True, null=True)
    children = models.CharField(max_length=3, choices=YES_NO_CHOICES, blank=True, null=True)
    children_in_congregation = models.PositiveIntegerField(blank=True, null=True)

    # Service interests
    ministries = models.TextField(
        blank=True,
        null=True,
        help_text="Store selected ministries as comma-separated values."
    )
    worship_areas = models.TextField(
        blank=True,
        null=True,
        help_text="Store selected worship areas as comma-separated values."
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.firstname or ''} {self.lastname or ''}".strip() or "Church Member"

class Attendance(models.Model):
    ATTENDANCE_CHOICES = [
        ("Absent", "Absent"),
        ("In Person", "In Person"),
        ("Zoom", "Zoom"),
    ]

    member = models.ForeignKey(ChurchMember, on_delete=models.CASCADE)
    date = models.DateField()
    status = models.CharField(max_length=20, choices=ATTENDANCE_CHOICES, default="Absent")
    note = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        unique_together = ("member", "date")

    def __str__(self):
        return f"{self.member} - {self.date} - {self.status}"

    from django.db import models

class GuestInformation(models.Model):
    AGE_CHOICES = [
        ("20s", "20s"),
        ("30s", "30s"),
        ("40s", "40s"),
        ("50s", "50s"),
        ("60s", "60s"),
        ("70s+", "70s+"),
    ]

    YES_NO_CHOICES = [
        ("Yes", "Yes"),
        ("No", "No"),
    ]

    date = models.DateField(blank=True, null=True)
    name = models.CharField(max_length=200)
    address = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    state = models.CharField(max_length=100, blank=True, null=True)
    zip_code = models.CharField(max_length=20, blank=True, null=True)

    phone_home = models.CharField(max_length=20, blank=True, null=True)
    phone_mobile = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)

    first_time_guest = models.BooleanField(default=False)
    returning_guest = models.BooleanField(default=False)
    new_to_area = models.BooleanField(default=False)
    would_like_visit = models.BooleanField(default=False)
    would_like_more_info = models.BooleanField(default=False)
    other = models.BooleanField(default=False)

    married = models.BooleanField(default=False)
    single = models.BooleanField(default=False)
    single_parent = models.BooleanField(default=False)
    widowed = models.BooleanField(default=False)
    college = models.BooleanField(default=False)
    high_school = models.BooleanField(default=False)
    middle_school = models.BooleanField(default=False)

    age_group = models.CharField(max_length=10, choices=AGE_CHOICES, blank=True, null=True)
    children_at_home = models.CharField(max_length=3, choices=YES_NO_CHOICES, blank=True, null=True)
    number_of_children = models.PositiveIntegerField(blank=True, null=True)

    home_church = models.CharField(max_length=200, blank=True, null=True)
    guest_of = models.CharField(max_length=200, blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name








    

