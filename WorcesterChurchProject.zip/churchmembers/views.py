from datetime import date
import openpyxl
from django.contrib import messages
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render

from .models import Attendance, ChurchMember, GuestInformation


def welcome(request):
    return render(request, "churchmembers/welcome.html")


def churchmembers(request):
    if request.method == "POST":
        ministries = ", ".join(request.POST.getlist("ministries[]"))
        worship = ", ".join(request.POST.getlist("worship[]"))

        ChurchMember.objects.create(
            firstname=request.POST.get("firstname"),
            lastname=request.POST.get("lastname"),
            address=request.POST.get("address"),
            home_phone=request.POST.get("home_phone"),
            cell_phone=request.POST.get("cell_phone"),
            email=request.POST.get("email"),
            birthday=request.POST.get("birthday") or None,
            baptismal_date=request.POST.get("baptismal_date") or None,
            originating_congregation=request.POST.get("originating_congregation"),
            membership_date=request.POST.get("membership_date") or None,
            old_congregation_contact=request.POST.get("old_congregation_contact"),
            move_date=request.POST.get("move_date"),
            live_with=request.POST.get("live_with"),
            married_now=request.POST.get("married_now"),
            married_before=request.POST.get("married_before"),
            children=request.POST.get("children"),
            children_in_congregation=request.POST.get("children_in_congregation") or None,
            ministries=ministries,
            worship_areas=worship,
        )

        messages.success(request, "Member registered successfully.")
        return redirect("member_list")

    return render(request, "churchmembers/registration.html")


def member_list(request):
    query = request.GET.get("q", "").strip()
    mychurchmembers = ChurchMember.objects.all().order_by("-created_at")

    if query:
        mychurchmembers = mychurchmembers.filter(
            Q(firstname__icontains=query)
            | Q(lastname__icontains=query)
            | Q(email__icontains=query)
            | Q(cell_phone__icontains=query)
            | Q(address__icontains=query)
        ).order_by("-created_at")

    return render(
        request,
        "churchmembers/RegisteredMembers.html",
        {
            "mychurchmembers": mychurchmembers,
            "query": query,
        },
    )


def edit_member(request, member_id):
    member = get_object_or_404(ChurchMember, id=member_id)

    if request.method == "POST":
        member.firstname = request.POST.get("firstname")
        member.lastname = request.POST.get("lastname")
        member.address = request.POST.get("address")
        member.home_phone = request.POST.get("home_phone")
        member.cell_phone = request.POST.get("cell_phone")
        member.email = request.POST.get("email")
        member.birthday = request.POST.get("birthday") or None
        member.baptismal_date = request.POST.get("baptismal_date") or None
        member.originating_congregation = request.POST.get("originating_congregation")
        member.membership_date = request.POST.get("membership_date") or None
        member.old_congregation_contact = request.POST.get("old_congregation_contact")
        member.move_date = request.POST.get("move_date")
        member.live_with = request.POST.get("live_with")
        member.married_now = request.POST.get("married_now")
        member.married_before = request.POST.get("married_before")
        member.children = request.POST.get("children")
        member.children_in_congregation = request.POST.get("children_in_congregation") or None
        member.ministries = ", ".join(request.POST.getlist("ministries[]"))
        member.worship_areas = ", ".join(request.POST.getlist("worship[]"))
        member.save()

        messages.success(request, "Member updated successfully.")
        return redirect("member_list")

    return render(
        request,
        "churchmembers/EditMember.html",
        {
            "member": member,
        },
    )


def delete_member(request, member_id):
    member = get_object_or_404(ChurchMember, id=member_id)

    if request.method == "POST":
        member.delete()
        messages.success(request, "Member deleted successfully.")
        return redirect("member_list")

    return render(
        request,
        "churchmembers/DeleteMember.html",
        {
            "member": member,
        },
    )


def export_members_excel(request):
    workbook = openpyxl.Workbook()
    worksheet = workbook.active
    worksheet.title = "Registered Members"

    headers = [
        "First Name",
        "Last Name",
        "Email",
        "Cell Phone",
        "Home Phone",
        "Address",
        "Birthday",
        "Baptismal Date",
        "Originating Congregation",
        "Membership Date",
        "Old Congregation Contact",
        "Move Date",
        "Live With",
        "Married Now",
        "Married Before",
        "Children",
        "Children In Congregation",
        "Ministries",
        "Worship Areas",
        "Created At",
    ]

    worksheet.append(headers)

    members = ChurchMember.objects.all().order_by("-created_at")

    for member in members:
        worksheet.append(
            [
                member.firstname,
                member.lastname,
                member.email,
                member.cell_phone,
                member.home_phone,
                member.address,
                member.birthday.strftime("%Y-%m-%d") if member.birthday else "",
                member.baptismal_date.strftime("%Y-%m-%d") if member.baptismal_date else "",
                member.originating_congregation,
                member.membership_date.strftime("%Y-%m-%d") if member.membership_date else "",
                member.old_congregation_contact,
                member.move_date,
                member.live_with,
                member.married_now,
                member.married_before,
                member.children,
                member.children_in_congregation,
                member.ministries,
                member.worship_areas,
                member.created_at.strftime("%Y-%m-%d %H:%M:%S") if member.created_at else "",
            ]
        )

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = 'attachment; filename="registered_members.xlsx"'

    workbook.save(response)
    return response


def mark_attendance(request):
    members = ChurchMember.objects.all().order_by("firstname", "lastname")
    selected_date = request.POST.get("date") or date.today().isoformat()

    if request.method == "POST":
        for member in members:
            status = request.POST.get(f"status_{member.id}", "Absent")

            Attendance.objects.update_or_create(
                member=member,
                date=selected_date,
                defaults={"status": status},
            )

        messages.success(request, "Attendance saved successfully.")
        return redirect("mark_attendance")

    return render(
        request,
        "churchmembers/attendance.html",
        {
            "members": members,
            "selected_date": selected_date,
        },
    )


def attendance_statistics(request):
    start_date = request.GET.get("start_date")
    end_date = request.GET.get("end_date")

    attendance_records = Attendance.objects.all()

    if start_date:
        attendance_records = attendance_records.filter(date__gte=start_date)

    if end_date:
        attendance_records = attendance_records.filter(date__lte=end_date)

    total_records = attendance_records.count()
    in_person_count = attendance_records.filter(status="In Person").count()
    zoom_count = attendance_records.filter(status="Zoom").count()
    absent_count = attendance_records.filter(status="Absent").count()

    member_stats = []

    members = ChurchMember.objects.all().order_by("firstname", "lastname")

    for member in members:
        member_attendance = attendance_records.filter(member=member)

        in_person = member_attendance.filter(status="In Person").count()
        zoom = member_attendance.filter(status="Zoom").count()
        absent = member_attendance.filter(status="Absent").count()

        member_stats.append(
            {
                "member": member,
                "in_person": in_person,
                "zoom": zoom,
                "absent": absent,
                "total_present": in_person + zoom,
            }
        )

    return render(
        request,
        "churchmembers/attendance_statistics.html",
        {
            "total_records": total_records,
            "in_person_count": in_person_count,
            "zoom_count": zoom_count,
            "absent_count": absent_count,
            "member_stats": member_stats,
            "start_date": start_date,
            "end_date": end_date,
        },
    )


def guest_information(request):
    if request.method == "POST":
        GuestInformation.objects.create(
            date=request.POST.get("date") or None,
            name=request.POST.get("name"),
            address=request.POST.get("address"),
            city=request.POST.get("city"),
            state=request.POST.get("state"),
            zip_code=request.POST.get("zip_code"),
            phone_home=request.POST.get("phone_home"),
            phone_mobile=request.POST.get("phone_mobile"),
            email=request.POST.get("email"),
            first_time_guest=bool(request.POST.get("first_time_guest")),
            returning_guest=bool(request.POST.get("returning_guest")),
            new_to_area=bool(request.POST.get("new_to_area")),
            would_like_visit=bool(request.POST.get("would_like_visit")),
            would_like_more_info=bool(request.POST.get("would_like_more_info")),
            other=bool(request.POST.get("other")),
            married=bool(request.POST.get("married")),
            single=bool(request.POST.get("single")),
            single_parent=bool(request.POST.get("single_parent")),
            widowed=bool(request.POST.get("widowed")),
            college=bool(request.POST.get("college")),
            high_school=bool(request.POST.get("high_school")),
            middle_school=bool(request.POST.get("middle_school")),
            age_group=request.POST.get("age_group"),
            children_at_home=request.POST.get("children_at_home"),
            number_of_children=request.POST.get("number_of_children") or None,
            home_church=request.POST.get("home_church"),
            guest_of=request.POST.get("guest_of"),
        )

        messages.success(request, "Guest information submitted successfully.")
        return redirect("guest_information")

    return render(request, "churchmembers/GuestInformation.html")


def guest_records(request):
    start_date = request.GET.get("start_date")
    end_date = request.GET.get("end_date")

    guests = GuestInformation.objects.all().order_by("-created_at")

    if start_date:
        guests = guests.filter(date__gte=start_date)

    if end_date:
        guests = guests.filter(date__lte=end_date)

    total_guests = guests.count()
    first_time_count = guests.filter(first_time_guest=True).count()
    returning_count = guests.filter(returning_guest=True).count()
    visit_request_count = guests.filter(would_like_visit=True).count()

    return render(
        request,
        "churchmembers/guest_records.html",
        {
            "guests": guests,
            "total_guests": total_guests,
            "first_time_count": first_time_count,
            "returning_count": returning_count,
            "visit_request_count": visit_request_count,
            "start_date": start_date,
            "end_date": end_date,
        },
    )


